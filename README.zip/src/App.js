import {
  BrowserRouter as Router,
  Switch,
  Route
} from "react-router-dom";

import Header from './Includes/Header'

import About from './Pages/About'
import Home from './Pages/Home'
import Contact from './Pages/Contact'

function App() {
  return (
    <>
      <Router>
        <Header />
        <div className="container mt-2">
        <Switch>
              <Route exact path="/" component={Home} />
              <Route exact path="/about" component={About} />
              <Route exact path="/contact" component={Contact} />
        </Switch>
        </div>
      </Router>
    </>
  );
}

export default App;
