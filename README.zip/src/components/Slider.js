import React from 'react'

export default function Slider() {
    return (
        <>
           <div className="carousel-item active">
                <img className="d-block w-100" src="https://i.pinimg.com/originals/45/74/c6/4574c68d814dc0d3a64611ee401ea7dc.jpg" alt="First slide" />
            </div> 
        </>
    )
}
