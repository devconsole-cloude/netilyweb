import React, { Component } from 'react'


export default class Home extends Component {
    render() {
        return (
            <>
            <div id="carouselExampleSlidesOnly" className="carousel slide" data-ride="carousel">
                <div className="carousel-inner">
                   
                    <div className="carousel-item active">
                    <img className="d-block w-100" src="https://i.pinimg.com/originals/45/74/c6/4574c68d814dc0d3a64611ee401ea7dc.jpg" alt="First slide" />
                    </div>
                    <div className="carousel-item">
                    <img className="d-block w-100" src="https://i.pinimg.com/originals/21/11/07/211107005352a0accd79bf122b438ea8.jpg" alt="Second slide" />
                    </div>
                </div>
            </div>
            </>
        )
    }
}
